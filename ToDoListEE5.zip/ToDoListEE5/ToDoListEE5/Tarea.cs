﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToDoListEE5
{
    public class Tarea
    {
        public string Work { get; set; }
        public string Hora { get; set; }
        public DateTime Fecha { get; set; }
        public string Status { get; set; }
        public int NoTarea { get; set; }
        public string NombreE { get; set; }

    }
}
