﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToDoListEE5
{
    public partial class frmStatus : Form
    {
        public frmStatus()
        {
            InitializeComponent();
            this.Text = "CAMBIAR ESTADO";
            this.BackColor = Color.LightSkyBlue;
        }

        private void BtnA_Click(object sender, EventArgs e)
        {

        }

        private void frmStatus_Load(object sender, EventArgs e)
        {

        }
    }
}
